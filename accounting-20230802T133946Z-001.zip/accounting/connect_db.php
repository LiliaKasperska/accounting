<?php

$host="localhost";
$user="lilia";
$user_password="332263";
$database="t_accounting";

//підключення до бд
$connect = mysqli_connect($host,$user, $user_password, $database);

?>